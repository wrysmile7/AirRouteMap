$(function () {
    var dataArr = [];
    var dataAirports = [];
    var featureInfo = [];
    var featureOn;
    var routeInfo = [];
    var vectorAir;
    var vectorRouteSolid;
    var vectorRouteDotted;
    var vectorAirports;
    var positionBgx = 0;
    var positionBgy = -240;
    var pointUrl = './img/planes_large.png';
    var anchor = [1, 1];
    var popupState = false;
    var icao = '';
    var timer;//创建定时器
    var count = 0;//计时数字
    var endAir;//终到站机场
    var routeArrSolid = [];
    var routeArrDotted = [];
    var map = new ol.Map({
        target: 'map',
        layers: [
            new ol.layer.Tile({
                // source: new ol.source.OSM()
                source: new ol.source.XYZ({
                    url: 'http://www.google.cn/maps/vt?lyrs=m@189&gl=cn&x={x}&y={y}&z={z}'
                }),
                style: new ol.style.Fill({
                    fill: new ol.style.Fill({
                        color: 'rgba(0,0,0,0.5)'
                    })
                })
            })
        ],
        view: new ol.View({
            // center: ol.proj.fromLonLat([37.41, 8.82]),
            center: ol.proj.transform([119.5697, 23.2876], 'EPSG:4326', 'EPSG:3857'),
            zoom: 9
        })
    });
    //请求航班数据
    function getAirplanes() {
        $.ajax({
            type: "GET",
            url: "https://opensky-network.org/api/states/all?extended=true",
            cache: false,
            success: function (data) {
                // console.log(data)
                dataArr = [];
                data.states.forEach(function (value) {
                    // console.log(value)
                    dataArr.push({
                        mode_s_code: value[0],
                        callsign: value[1],
                        // origin_country: value[2],
                        // time_position: value[3],
                        // last_contact: value[4],
                        value: [value[5], value[6]],
                        // baro_altitude: value[7],
                        // on_ground: value[8],
                        // velocity: value[9],
                        true_track: value[10],
                        // vertical_rate: value[11],
                        // sensors: value[12],
                        // geo_altitude: value[13],
                        // squawk: value[14],
                        // spi: value[15],
                        // position_source: value[16]
                    })
                });
                // console.log(dataArr)
                var len = $.isEmptyObject(vectorAir);
                if (len == false) {
                    vectorAir.getSource().clear();
                }
                // console.log(popupState)
                if (popupState == true) {
                    getPopupData(icao);
                }
                showPoint(dataArr, 'Airplanes');
            }
        });
    }
    //请求所有机场数据
    function getAirports() {
        $.ajax({
            type: "GET",
            url: "https://opensky-network.org/api/airports/region?lamin=-180&lamax=180&lomin=-180&lomax=180&type=large_airport",
            dataType: "json",
            success: function (data) {
                // console.log(data);
                data.forEach(function(value){
                    dataAirports.push({
                        city: value.city,
                        iata: value.iata,
                        icao: value.icao,
                        name: value.name,
                        type: value.type,
                        altitude: value.position.altitude,
                        reasonable: value.position.reasonable,
                        value: [value.position.longitude, value.position.latitude]
                    })
                });
                showPoint(dataAirports, 'Airports');
            }
        });
    }
    //画点
    function showPoint(data, types) {
        var features = new Array(data.length);
        var feature, geometry;
        // console.log(data)
        for (var i = 0; i < data.length; i++) {
            geometry = new ol.geom.Point(ol.proj.fromLonLat(data[i].value));
            var point = new ol.Feature({
                geometry: new ol.geom.Point(ol.proj.fromLonLat(data[i].value))
            });
            feature = new ol.Feature(geometry);
            // console.log(feature);
            if (types == 'Airplanes') {
                featureInfo.push({
                    geo: point,
                    wn: feature.Wn,
                    att: {
                        mode_s_code: data[i].mode_s_code,
                        callsign: data[i].callsign,
                        // origin_country: data[i].origin_country,
                        // time_position: data[i].time_position,
                        // last_contact: data[i].last_contact,
                        value: data[i].value,
                        // baro_altitude: data[i].baro_altitude,
                        // on_ground: data[i].on_ground,
                        // velocity: data[i].velocity,
                        // true_track: data[i].true_track,
                        // vertical_rate: data[i].vertical_rate,
                        // sensors: data[i].sensors,
                        // geo_altitude: data[i].geo_altitude,
                        // squawk: data[i].squawk,
                        // spi: data[i].spi,
                        // position_source: data[i].position_source
                    }
                })
                trueTrack(data[i].true_track);
                // console.log(data[i].mode_s_code)
                if (popupState == true) {
                    if (data[i].mode_s_code == icao) {
                        feature.setStyle(
                            new ol.style.Style({
                                image: new ol.style.Icon({
                                    src: pointUrl,
                                    size: [60, 60],
                                    scale: 0.6,
                                    offset: [-positionBgx, 60],
                                    color: 'orange'
                                })
                            })
                        )
                    } else {
                        feature.setStyle(
                            new ol.style.Style({
                                image: new ol.style.Icon({
                                    src: pointUrl,
                                    size: [60, 60],
                                    scale: 0.6,
                                    offset: [-positionBgx, 60],
                                    // color: 'red'
                                })
                            })
                        )
                    }
                } else {
                    feature.setStyle(
                        new ol.style.Style({
                            image: new ol.style.Icon({
                                src: pointUrl,
                                size: [60, 60],
                                scale: 0.6,
                                offset: [-positionBgx, 60],
                                // color: 'red'
                            })
                        })
                    )
                }
            }
            if (types == 'Airports') {
                featureInfo.push({
                    geo: point,
                    wn: feature.Wn,
                    att: {
                        altitude: data[i].altitude,
                        city: data[i].city,
                        iata: data[i].iata,
                        icao: data[i].icao,
                        name: data[i].name,
                        reasonable: data[i].reasonable,
                        type: data[i].type,
                        value: data[i].value,
                    }
                })
                feature.setStyle(
                    new ol.style.Style({
                        image: new ol.style.Circle({
                            radius: 2.5,
                            stroke: new ol.style.Stroke({
                                color: 'blue',
                                width: 5
                            })
                        })
                    })
                )
            }
            features[i] = feature;
        }
        var vecorSource = new ol.source.Vector({
            features: features
        });
        if (types == 'Airplanes') {
            vectorAir = new ol.layer.Vector({
                source: vecorSource
            });
            map.addLayer(vectorAir);
            getAirplanes();
        }
        if (types == 'Airports') {
            vectorAirports = new ol.layer.Vector({
                source: vecorSource
            });
            map.addLayer(vectorAirports);
        }
    }
    //画航线
    function showRoute(data, types) {
        var feature, source = new ol.source.Vector();
        var geometry = new ol.geom.LineString();
        for (let i = 0; i < data.length; i++) {
            geometry.appendCoordinate(ol.proj.transform(data[i], 'EPSG:4326', 'EPSG:3857'));
        }
        feature = new ol.Feature({
            geometry: geometry
        });
        // console.log(feature)
        source.addFeature(feature);
        routeInfo.push({
            geo: geometry,
            wn: feature.Wn,
            att: {

            }
        });
        if (types == 'solid') {
            vectorRouteSolid = new ol.layer.Vector({
                source: source,
                style: new ol.style.Style({
                    stroke: new ol.style.Stroke({
                        width: 2,
                        color: 'blue'
                    })
                })
            });
            map.addLayer(vectorRouteSolid);
        }
        if (types == 'dotted') {
            vectorRouteDotted = new ol.layer.Vector({
                source: source,
                style: new ol.style.Style({
                    stroke: new ol.style.Stroke({
                        lineDash:[1,2,3,4,5],
                        width: 2,
                        color: 'red'
                    })
                })
            });
            map.addLayer(vectorRouteDotted);
        }
    }
    map.on('click', function (evt) {
        evt.preventDefault();
        featureOn = map.forEachFeatureAtPixel(evt.pixel, function (feature, layer) { return feature });
        if (featureOn) {
            for (var i = 0; i < featureInfo.length; i++) {
                if (featureOn.Wn == featureInfo[i].wn) {
                    console.log(featureInfo[i].att)
                    var data = featureInfo[i].att;
                    // trueTrack(data.true_track);
                    icao = data.mode_s_code;
                    popupState = true;
                    routeArrSolid = [];
                    routeArrDotted = [];
                    var len = $.isEmptyObject(vectorAir);
                    if (len == false) {
                        vectorAir.getSource().clear();
                    }
                    showPoint(dataArr, 'Airplanes');
                    getPopupData(data.mode_s_code);
                    $(".popup").slideDown();
                    var lenS = $.isEmptyObject(vectorRouteSolid);
                    if (lenS == false) {
                        vectorRouteSolid.getSource().clear();
                    }
                    var lenD = $.isEmptyObject(vectorRouteDotted);
                    if (lenD == false) {
                        vectorRouteDotted.getSource().clear();
                    }
                    routeArrSolid.push(data.value);
                    routeArrDotted.push(data.value);
                    // $.ajax({//获取航线轨迹
                    //     type: "GET",
                    //     url: "https://USERNAME:PASSWORD@opensky-network.org/api/tracks/all?icao24=" + data.mode_s_code + "&time=0",
                    //     // dataType: "json",
                    //     success: function (data) {
                    //         data.path.reverse();
                    //         data.path.forEach(function (value) {
                    //             routeArrSolid.push([value[2], value[1]]);
                    //         });
                    //         // console.log(routeArrSolid)
                    //         showRoute(routeArrSolid, 'solid');
                    //     }
                    // });
                    $.ajax({//获取注册、模型、所有者信息
                        type: "GET",
                        url: "https://opensky-network.org/api/metadata/aircraft/icao/" + data.mode_s_code,
                        // dataType: "json",
                        success: function (data) {
                            console.log(data)
                            $("#regist").text(data.registration);
                            $("#model").text(data.model);
                            $("#owner").text(data.owner);
                        }
                    });
                    $.ajax({//获取航班信息
                        type: "GET",
                        url: "https://opensky-network.org/api/routes?callsign=" + data.callsign,
                        // dataType: "json",
                        success: function (data) {
                            console.log(data)
                            $("#airNum").text(data.operatorIata + data.flightNumber);
                            $("#startAir").text(data.route[0]);
                            $("#endAir").text(data.route[1]);
                            $("#flight").text(data.operatorIata + data.flightNumber);
                            $(".route-none").hide();
                            $(".fidRouteAirports").show();
                            $(".report-error").show();
                            for (let i = 0, len = data.route.length; i < len; i++) {
                                $.ajax({
                                    type: "GET",
                                    url: "https://opensky-network.org/api/airports/?icao=" + data.route[i],
                                    // dataType: "json",
                                    success: function (_data) {
                                        console.log(_data)
                                        if (i == 0) {
                                            $("#startCity").text(_data.municipality);
                                        }
                                        if (i == 1) {
                                            $("#endCity").text(_data.municipality);
                                        }
                                        if (i == len-1) {
                                            endAir = data.route[i];
                                            routeArrDotted.push([_data.position.longitude, _data.position.latitude]);
                                            showRoute(routeArrDotted, 'dotted');
                                        }
                                    }
                                });
                            }
                        },
                        error: function (data) {
                            $(".fidRouteAirports").hide();
                            $(".report-error").hide();
                            $(".route-none").show();
                        }
                    });
                }
            }
        } else {
            popupState = false;
            clearInterval(timer);
            count = 0;
            $(".popup").slideUp();
            var lenD = $.isEmptyObject(vectorRouteDotted);
            if (lenD == false) {
                vectorRouteDotted.getSource().clear();
            }
            var len = $.isEmptyObject(vectorAir);
            if (len == false) {
                vectorAir.getSource().clear();
            }
            showPoint(dataArr, 'Airplanes');
        }
    });
    //弹框数据获取
    function getPopupData(mode_s_code){
        $.ajax({
            type: "GET",
            url: "https://opensky-network.org/api/states/all?icao24=" + mode_s_code,
            // dataType: "json",
            success: function (data) {
                // console.log(data)
                clearInterval(timer);
                count = 0;
                var data = data.states[0];
                let reg = new RegExp(' ', 'g');
                let origin_country = data[2].replace(reg, '_');
                trueTrack(data[10]);
                // featureOn.setStyle(
                //     new ol.style.Style({
                //         image: new ol.style.Icon({
                //             src: pointUrl,
                //             size: [60, 60],
                //             scale: 0.6,
                //             offset: [-positionBgx, 60],
                //             color: 'orange'
                //         })
                //     })
                // )
                $(".flag").attr('src', './img/' + origin_country + '.png');
                $(".flag").attr('title', data[2]);
                $(".air-model").css({
                    'background-position-x': positionBgx + 'px',
                    'background-position-y': positionBgy + 'px'
                });
                $("#mode_s_code").text(data[0]);
                $("#callsign").text(data[1]);
                $("#velocity").text(Math.floor(data[9] * 3600 / 1852) + '节 (' + Math.floor(data[9] * 3.6) + '公里/小时)');
                $("#true_track").text(Math.floor(data[10]) + '°');
                $("#geo_altitude").text(Math.floor(data[13] * 3.2808399) + '英尺 (' + Math.floor(data[13]) + '米)');
                $("#baro_altitude").text(Math.floor(data[7] * 3.2808399) + '英尺 (' + Math.floor(data[7]) + '米)');
                $("#vertical_rate").text(Math.floor(data[11] * 3.2808399 * 60) + '英尺/分钟 (' + data[11].toFixed(1) + '米/秒)');
                $("#squawk").text(data[14]);
                //实时更新飞机与终到站机场之间的航线
                routeArrDotted[0] = [data[5], data[6]];
                var lenD = $.isEmptyObject(vectorRouteDotted);
                if (lenD == false) {
                    vectorRouteDotted.getSource().clear();
                }
                showRoute(routeArrDotted, 'dotted');
                timer = setInterval(function(){
                    $("#times").text(count);
                    count++;
                },1000);
            }
        });
    }
    //飞机图片朝向
    function trueTrack(true_track) {
        if (true_track > 6 & true_track < 19) {
            positionBgx = -60;
            positionBgy = -240;
        } else if (true_track > 18 & true_track < 31) {
            positionBgx = -120;
            positionBgy = -240;
        } else if (true_track > 30 & true_track < 43) {
            positionBgx = -180;
            positionBgy = -240;
        } else if (true_track > 42 & true_track < 55) {
            positionBgx = -240;
            positionBgy = -240;
        } else if (true_track > 54 & true_track < 67) {
            positionBgx = -300;
            positionBgy = -240;
        } else if (true_track > 66 & true_track < 79) {
            positionBgx = -360;
            positionBgy = -240;
        } else if (true_track > 78 & true_track < 91) {
            positionBgx = -420;
            positionBgy = -240;
        } else if (true_track > 90 & true_track < 103) {
            positionBgx = -480;
            positionBgy = -240;
        } else if (true_track > 102 & true_track < 115) {
            positionBgx = -540;
            positionBgy = -240;
        } else if (true_track > 114 & true_track < 127) {
            positionBgx = -600;
            positionBgy = -240;
        } else if (true_track > 126 & true_track < 139) {
            positionBgx = -660;
            positionBgy = -240;
        } else if (true_track > 138 & true_track < 151) {
            positionBgx = -720;
            positionBgy = -240;
        } else if (true_track > 150 & true_track < 163) {
            positionBgx = -780;
            positionBgy = -240;
        } else if (true_track > 162 & true_track < 175) {
            positionBgx = -840;
            positionBgy = -240;
        } else if (true_track > 174 & true_track < 187) {
            positionBgx = -900;
            positionBgy = -240;
        } else if (true_track > 186 & true_track < 199) {
            positionBgx = -960;
            positionBgy = -240;
        } else if (true_track > 198 & true_track < 211) {
            positionBgx = -1020;
            positionBgy = -240;
        } else if (true_track > 210 & true_track < 223) {
            positionBgx = -1080;
            positionBgy = -240;
        } else if (true_track > 222 & true_track < 235) {
            positionBgx = -1140;
            positionBgy = -240;
        } else if (true_track > 234 & true_track < 247) {
            positionBgx = -1200;
            positionBgy = -240;
        } else if (true_track > 246 & true_track < 259) {
            positionBgx = -1260;
            positionBgy = -240;
        } else if (true_track > 258 & true_track < 271) {
            positionBgx = -1320;
            positionBgy = -240;
        } else if (true_track > 270 & true_track < 283) {
            positionBgx = -1380;
            positionBgy = -240;
        } else if (true_track > 282 & true_track < 295) {
            positionBgx = -1440;
            positionBgy = -240;
        } else if (true_track > 294 & true_track < 307) {
            positionBgx = -1500;
            positionBgy = -240;
        } else if (true_track > 306 & true_track < 319) {
            positionBgx = -1560;
            positionBgy = -240;
        } else if (true_track > 318 & true_track < 331) {
            positionBgx = -1620;
            positionBgy = -240;
        } else if (true_track > 330 & true_track < 343) {
            positionBgx = -1680;
            positionBgy = -240;
        } else if (true_track > 342 & true_track < 355) {
            positionBgx = -1740;
            positionBgy = -240;
        } else {
            positionBgx = 0;
            positionBgy = -240;
            // pointUrl = './img/point1.png';
        }
    }
    getAirplanes();
    getAirports();
});